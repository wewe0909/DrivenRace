using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamaraController : MonoBehaviour
{
    // Referencia al coche
    public GameObject coche;

    // Offset para la posici�n detr�s del coche y en frente del coche
    private Vector3 offsetDetras = new Vector3(3.6f, 2f, -10f);
    private Vector3 offsetFrente = new Vector3(2f, 2f, 8f);

    // Booleano para saber si la c�mara est� en modo "mirar hacia atr�s"
    private bool mirandoFrente = false;

    void LateUpdate()
    {
        // Detecta si se presiona o suelta la rueda del rat�n
        if (Input.GetMouseButtonDown(2)) // Bot�n 2 es la rueda del rat�n
        {
            mirandoFrente = true;
        }
        else if (Input.GetMouseButtonUp(2))
        {
            mirandoFrente = false;
        }

        // Calcula la posici�n de la c�mara dependiendo de si estamos mirando hacia adelante o hacia atr�s
        Vector3 posicionCamara;
        if (mirandoFrente)
        {
            // Coloca la c�mara en frente del coche mirando hacia �l
            posicionCamara = coche.transform.position + coche.transform.TransformDirection(offsetFrente);
            transform.position = posicionCamara;
            transform.LookAt(coche.transform.position);
        }
        else
        {
            // Coloca la c�mara detr�s del coche mirando hacia adelante
            posicionCamara = coche.transform.position + coche.transform.TransformDirection(offsetDetras);
            transform.position = posicionCamara;
            transform.LookAt(coche.transform.position + coche.transform.forward * 2);
        }
    }
}
