using UnityEngine;
using System.Collections;

public class CartPointToPoint : MonoBehaviour
{
    public float velocidad = 5f; // Velocidad del coche enemigo
    public float radioWaypoint = 1f; // Radio para cambiar al siguiente waypoint
    public float velocidadRotacion = 5f; // Velocidad de rotaci�n para suavizar el giro
    public string waypointTag = "Waypoint"; // Etiqueta de los waypoints
    public float delayInicio = 0f; // Retraso en segundos antes de que comience el movimiento

    public ParticleSystem explosionParticles; // Part�culas para la explosi�n
    public GameObject explosionPrefab; // Prefab de la explosi�n
    public Transform centroCarro; // El objeto donde se ejecutar� la animaci�n (CentroCarro)
    public GameObject explosionSoundObject; // Objeto vac�o para el sonido de la explosi�n

    private Transform[] waypoints; // Array de puntos de control
    private int indiceWaypointActual = 0; // �ndice del waypoint actual
    private bool iniciado = false; // Indica si el movimiento ha comenzado
    private bool explosionTriggered = false; // Evita m�ltiples explosiones

    void Start()
    {
        // Encuentra todos los objetos con la etiqueta "Waypoint" y gu�rdalos en el array
        GameObject[] objetosWaypoint = GameObject.FindGameObjectsWithTag(waypointTag);
        waypoints = new Transform[objetosWaypoint.Length];
        for (int i = 0; i < objetosWaypoint.Length; i++)
        {
            waypoints[i] = objetosWaypoint[i].transform;
        }

        // Inicia la cuenta regresiva para empezar
        Invoke(nameof(ComenzarMovimiento), delayInicio);

        if (centroCarro == null)
        {
            Debug.LogWarning("No se ha asignado el objeto CentroCarro para las animaciones.");
        }
    }

    void ComenzarMovimiento()
    {
        iniciado = true; // Permite que el movimiento comience
    }

    void Update()
    {
        if (!iniciado || waypoints.Length == 0 || explosionTriggered)
            return;

        // Obtenemos el waypoint actual
        Transform waypointObjetivo = waypoints[indiceWaypointActual];

        // Calcula la direcci�n hacia el waypoint actual
        Vector3 direccion = (waypointObjetivo.position - transform.position).normalized;

        // Suaviza el giro del coche hacia el waypoint
        if (direccion != Vector3.zero) // Evita errores al calcular rotaciones inv�lidas
        {
            Quaternion rotacionObjetivo = Quaternion.LookRotation(direccion);
            transform.rotation = Quaternion.Slerp(transform.rotation, rotacionObjetivo, velocidadRotacion * Time.deltaTime);
        }

        // Mueve el coche hacia adelante en la direcci�n actual
        transform.position += transform.forward * velocidad * Time.deltaTime;

        // Comprueba si el coche est� cerca del waypoint actual
        if (Vector3.Distance(transform.position, waypointObjetivo.position) < radioWaypoint)
        {
            indiceWaypointActual++;

            // Si ha alcanzado el �ltimo waypoint, destruye el objeto
            if (indiceWaypointActual >= waypoints.Length)
            {
                Destroy(gameObject);
            }
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player") && !explosionTriggered)
        {
            explosionTriggered = true;
            StartCoroutine(Explota());
        }
    }

    IEnumerator Explota()
    {
        // Verificar si el objeto "CentroCarro" est� asignado
        if (centroCarro != null)
        {
            // Si se tiene un prefab de explosi�n, instanciarlo en el CentroCarro
            if (explosionPrefab != null)
            {
                GameObject explosion = Instantiate(explosionPrefab, centroCarro.position, centroCarro.rotation);
                Destroy(explosion, 2f);
            }
            else if (explosionParticles != null)
            {
                explosionParticles.transform.position = centroCarro.position;
                explosionParticles.Play();
            }
        }
        else
        {
            Debug.LogWarning("No se ha asignado un objeto 'CentroCarro' para la animaci�n de explosi�n.");
        }

        // Reproducir el sonido de la explosi�n
        if (explosionSoundObject != null)
        {
            AudioSource audioSource = explosionSoundObject.GetComponent<AudioSource>();
            if (audioSource != null)
            {
                audioSource.Play();
            }
            else
            {
                Debug.LogWarning("El objeto de sonido no tiene un AudioSource asignado.");
            }
        }

        // Esperar un tiempo antes de destruir el coche
        yield return new WaitForSeconds(0.001f);
        Destroy(gameObject);
    }
}



