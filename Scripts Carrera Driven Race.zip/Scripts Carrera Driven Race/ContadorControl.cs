using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class ContadorControl : MonoBehaviour
{
    public GameObject objetoDetener; // Objeto que detendr� el contador
    public TextMeshProUGUI textoContador; // Referencia al texto en la UI
    private float contador = 0f; // Contador inicial
    private bool contando = true; // Estado del contador

    void Update()
    {
        if (contando)
        {
            contador += Time.deltaTime; // Incrementa el contador en tiempo real

            // Calcula los minutos y los segundos
            int minutos = Mathf.FloorToInt(contador / 60); // Calcula los minutos
            int segundos = Mathf.FloorToInt(contador % 60); // Calcula los segundos restantes

            // Actualiza el texto con el formato "minutos:segundos"
            textoContador.text = minutos.ToString("D2") + ":" + segundos.ToString("D2"); // D2 para siempre mostrar 2 dígitos
        }
    }

    public void PantallaMeta()
    {
        Debug.Log("");
        SceneManager.LoadScene("ifVictory_loading");
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == objetoDetener)
        {
            contando = false; // Detiene el contador
            Debug.Log("�Contador detenido!");
            PantallaMeta();
        }
    }
}
