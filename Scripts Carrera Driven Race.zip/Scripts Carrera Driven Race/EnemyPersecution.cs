using UnityEngine;
using System.Collections;

public class EnemyPersecution : MonoBehaviour
{
    public Transform carroJugador; // Referencia al carro principal
    public float velocidad = 10f; // Velocidad de persecuci�n
    public float velocidadRotacion = 5f; // Velocidad de rotaci�n
    private bool persiguiendo = false; // Si el carro enemigo est� persiguiendo
    private float temporizadorPersecucion = 0f; // Tiempo restante de persecuci�n

    // Para la explosi�n
    public ParticleSystem explosionParticles; // Part�culas para la explosi�n
    public GameObject explosionPrefab; // Prefab de la explosi�n
    public Transform centroCarro;  // El objeto donde se ejecutar� la animaci�n (CentroCarro)
    private bool explosionTriggered = false; // Para evitar que se repita la explosi�n

    // Objeto con sonido de explosi�n
    public GameObject explosionSoundObject;  // Objeto que contiene el AudioSource de la explosi�n
    private AudioSource explosionAudioSource;  // Referencia al AudioSource de ese objeto

    // Tiempo de vida del coche antes de destruirlo
    public float tiempoVida = 10f; // Tiempo de vida en segundos (lo podr�s modificar desde el Inspector)
    private float tiempoVidaRestante;

    void Start()
    {
        // Obtener el AudioSource del objeto ExplosionSoundObject
        if (explosionSoundObject != null)
        {
            explosionAudioSource = explosionSoundObject.GetComponent<AudioSource>();
            if (explosionAudioSource == null)
            {
                Debug.LogWarning("El objeto ExplosionSoundObject no tiene un AudioSource.");
            }
        }
        else
        {
            Debug.LogWarning("No se ha asignado el objeto ExplosionSoundObject.");
        }

        // Verificar si se ha asignado el objeto "CentroCarro"
        if (centroCarro == null)
        {
            Debug.LogWarning("No se ha asignado el objeto CentroCarro para las animaciones.");
        }

        // Inicializar el tiempo de vida restante con el valor del Inspector
        tiempoVidaRestante = tiempoVida;
    }

    void Update()
    {
        // Comienza la persecuci�n y el conteo del tiempo de vida si est� persiguiendo
        if (persiguiendo && carroJugador != null)
        {
            // Calcular la direcci�n hacia el carro jugador
            Vector3 direccion = (carroJugador.position - transform.position).normalized;

            // Calcular la rotaci�n necesaria para mirar hacia el jugador
            Quaternion rotacionObjetivo = Quaternion.LookRotation(direccion);
            transform.rotation = Quaternion.Slerp(transform.rotation, rotacionObjetivo, velocidadRotacion * Time.deltaTime);

            // Mover el enemigo hacia el jugador en la direcci�n deseada
            transform.position += transform.forward * velocidad * Time.deltaTime;

            // Actualizar el temporizador de persecuci�n
            temporizadorPersecucion -= Time.deltaTime;
            if (temporizadorPersecucion <= 0)
            {
                DetenerPersecucion();
            }

            // Reducir el tiempo de vida restante solo si estamos persiguiendo
            if (tiempoVidaRestante > 0)
            {
                tiempoVidaRestante -= Time.deltaTime;
            }
            else
            {
                // Si el tiempo de vida ha terminado, destruir el coche
                Destroy(gameObject);
            }
        }
    }

    // M�todo para iniciar la persecuci�n
    public void IniciarPersecucion(float duracion)
    {
        Debug.Log("Persecuci�n iniciada por " + duracion + " segundos.");
        persiguiendo = true;
        temporizadorPersecucion = duracion;

        // Iniciar el conteo del tiempo de vida cuando empieza la persecuci�n
        tiempoVidaRestante = tiempoVida; // Reiniciar el tiempo de vida a la cantidad configurada
    }

    // M�todo para detener la persecuci�n
    public void DetenerPersecucion()
    {
        Debug.Log("Persecuci�n detenida.");
        persiguiendo = false;
    }

    // M�todo para manejar la colisi�n con el jugador y la explosi�n
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            // Si ya se ha producido la explosi�n, no hacer nada m�s
            if (explosionTriggered) return;

            // Marcar la explosi�n como ocurrida
            explosionTriggered = true;

            // Llamar a la funci�n de explosi�n
            StartCoroutine(Explota());
        }
    }

    // M�todo para gestionar la explosi�n con un retraso en la destrucci�n
    IEnumerator Explota()
    {
        // Verificar si el objeto "CentroCarro" est� asignado
        if (centroCarro != null)
        {
            // Si se tiene un prefab de explosi�n, instanciarlo en el CentroCarro
            if (explosionPrefab != null)
            {
                GameObject explosion = Instantiate(explosionPrefab, centroCarro.position, centroCarro.rotation);
                Destroy(explosion, 2f);  // Destruir despu�s de que termine la animaci�n
            }
            else
            {
                // Si no tienes un prefab, usar part�culas
                if (explosionParticles != null)
                {
                    explosionParticles.transform.position = centroCarro.position; // Colocar las part�culas en la posici�n del "CentroCarro"
                    explosionParticles.Play(); // Reproducir la animaci�n de explosi�n
                }
            }
        }
        else
        {
            Debug.LogWarning("No se ha asignado un objeto 'CentroCarro' para la animaci�n de explosi�n.");
        }

        // Reproducir el sonido de la explosi�n usando el objeto de sonido
        if (explosionAudioSource != null)
        {
            explosionAudioSource.Play();  // Reproducir el sonido
        }
        else
        {
            Debug.LogWarning("No se ha asignado un AudioSource para el sonido de explosi�n.");
        }

        // Esperar 1 milisegundo despu�s de iniciar el sonido para destruir el coche
        yield return new WaitForSeconds(0.001f);

        // Destruir el coche despu�s de la explosi�n
        Destroy(gameObject);
    }
}






