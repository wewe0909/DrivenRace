using UnityEngine;
using UnityEngine.UI;
using System.Collections;  // Aseg�rate de que esto est� incluido para usar coroutines
using UnityEngine.SceneManagement;


public class HealthPoint : MonoBehaviour
{
    public float vida = 70f; // Vida inicial del coche
    public float vidaMaxima = 70f; // Vida m�xima (puede ser igual que "vida")
    public int golpesMaximos = 7; // N�mero de golpes que puede aguantar el coche
    public Image corazonIcono; // Icono del coraz�n que representar� la vida
    private carController carController;

    // Referencia al panel de pantalla negra
    public GameObject pantallaNegra;  // Asignar el Panel de pantalla negra en el Inspector
    private CanvasGroup canvasGroup;  // Referencia al CanvasGroup para controlar la opacidad

    private void Start()
    {
        carController = GetComponent<carController>(); // Obtener referencia al controlador del coche

        if (corazonIcono != null)
        {
            corazonIcono.type = Image.Type.Filled;
            corazonIcono.fillMethod = Image.FillMethod.Horizontal;
            corazonIcono.fillOrigin = 1; // Llenado de derecha a izquierda
        }

        // Aseg�rate de que la pantalla negra est� desactivada al inicio
        if (pantallaNegra != null)
        {
            pantallaNegra.SetActive(false);
            canvasGroup = pantallaNegra.GetComponent<CanvasGroup>();  // Obtener el CanvasGroup
        }
    }

    private void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.CompareTag("Auto"))
        {
            float danio = vidaMaxima / golpesMaximos; // Divide la vida m�xima seg�n el n�mero de golpes
            RecibirDanio(danio);
        }
    }

    public void RecibirDanio(float danio)
    {
        vida -= danio;
        vida = Mathf.Clamp(vida, 0, vidaMaxima); // Mantener el valor de vida entre 0 y vidaMaxima

        if (corazonIcono != null)
        {
            float porcentajeVida = vida / vidaMaxima; // Calcula el porcentaje de vida restante
            corazonIcono.fillAmount = porcentajeVida;

            if (vida < vidaMaxima * 0.3f) // Si la vida es menor al 30% del m�ximo
            {
                corazonIcono.color = Color.red;
            }
            else
            {
                corazonIcono.color = Color.yellow;
            }
        }

        if (vida <= 0)
        {
            carController.enabled = false;
            PantallaMuerte(); 
            // Desactivar el carro

            AudioSource audioSource = carController.GetComponent<AudioSource>();
            if (audioSource != null)
            {
                audioSource.Stop();
            }

        }
    }

    public void PantallaMuerte()
    {
        Debug.Log("");
        SceneManager.LoadScene("ifDefeat");
    }

    // Coroutine para aumentar la opacidad de la pantalla negra
    private IEnumerator AumentarOpacidad(float targetAlpha)
    {
        float duration = 1f; // Duraci�n del cambio de opacidad
        float startAlpha = canvasGroup.alpha;
        float timeElapsed = 0f;

        while (timeElapsed < duration)
        {
            timeElapsed += Time.deltaTime;
            canvasGroup.alpha = Mathf.Lerp(startAlpha, targetAlpha, timeElapsed / duration); // Gradualmente cambiar la opacidad
            yield return null;
        }

        // Aseg�rate de que la opacidad final sea exactamente 1
        canvasGroup.alpha = targetAlpha;
    }

    public void RegenerarVida(float cantidad)
    {
        if (vida < vidaMaxima)
        {
            vida += cantidad;
            vida = Mathf.Clamp(vida, 0, vidaMaxima); // Mantener la vida entre 0 y vidaMaxima

            // Actualizar el icono del coraz�n si est� asignado
            if (corazonIcono != null)
            {
                float porcentajeVida = vida / vidaMaxima; // Calcula el porcentaje de vida restante
                corazonIcono.fillAmount = porcentajeVida;

                // Cambiar el color del icono seg�n la vida
                if (vida < vidaMaxima * 0.3f) // Si la vida es menor al 30% del m�ximo
                {
                    corazonIcono.color = Color.red;
                }
                else
                {
                    corazonIcono.color = Color.white;
                }
            }
        }
    }
}
