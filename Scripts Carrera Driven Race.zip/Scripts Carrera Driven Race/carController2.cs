using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class carController2 : MonoBehaviour
{
    [System.Serializable]
    public class infoEje
    {
        public WheelCollider ruedaIzquierda;
        public WheelCollider ruedaDerecha;
        public bool motor;
        public bool direccion;
    }

    public List<infoEje> infoEjes;
    public float maxMotorTorsion;
    public float maxAnguloDeGiro;
    public float frenadoAdicional;
    public float aceleracionProgresiva = 1f;
    public float aceleracionRapida = 2f;
    public float velocidadInicial = 10f;
    public float friccionLateralNormal = 1.0f;
    public float friccionLateralDerrape = 0.3f;

    // Variables para sonido
    public AudioClip sonidoMotor;
    private AudioSource audioSource;

    private Vector3 posicionInicial;
    private Quaternion rotacionInicial;
    private float motorActual = 0;
    private bool enReversa;

    // Referencia al Rigidbody del coche
    private Rigidbody rb;

    // Punto de control
    private Transform ultimoPuntoDeControl;

    // Nueva funcionalidad: Vida y explosi�n
    public int vida = 3; // Vida inicial del coche
    public GameObject explosionPrefab; // Prefab de la explosi�n

    // Referencia para la persecuci�n del enemigo
    public GameObject carroEnemigo1; // Asignar en el Inspector
    public GameObject carroEnemigo2; // Asignar en el Inspector
    public GameObject carroEnemigo3; // Asignar en el Inspector
    public GameObject carroEnemigo4; // Asignar en el Inspector
    public float duracionPersecucion = 10f; // Duraci�n de la persecuci�n
    private int contadorCheckpoints = 0; // N�mero de checkpoints alcanzados


    // Variable para saber si el coche est� detenido
    private bool cocheDetenido = false;

    void Start()
    {
        posicionInicial = transform.position;
        rotacionInicial = transform.rotation;

        rb = GetComponent<Rigidbody>(); // Obtener el componente Rigidbody del coche

        // Configuraci�n de AudioSource
        if (sonidoMotor != null) // Verificar que el clip de sonido est� asignado
        {
            audioSource = gameObject.AddComponent<AudioSource>();
            audioSource.clip = sonidoMotor;
            audioSource.loop = true;
            audioSource.playOnAwake = false;
            audioSource.spatialBlend = 1f; // Sonido en 3D
            audioSource.maxDistance = 50f;
            audioSource.volume = 1.0f; // Volumen inicial m�ximo
        }
        else
        {
            Debug.LogError("AudioClip de sonidoMotor no asignado en el inspector.");
        }
    }

    void Update()
    {
        // Verifica si el coche est� detenido y no permitir m�s entradas
        if (cocheDetenido)
        {
            return; // Si el coche est� detenido, no ejecutamos m�s l�gica de controles
        }

        // Funcionalidad de volver al �ltimo punto de control
        if (Input.GetKeyDown(KeyCode.R))
        {
            if (ultimoPuntoDeControl != null)
                VolverAlUltimoPuntoDeControl();
            else
                ResetPosition();
        }

        // Reproduce el sonido del motor si el coche est� en movimiento
        if (audioSource != null)
        {
            bool cocheEnMovimiento = rb.velocity.magnitude > 0.1f; // Consideramos movimiento si la velocidad es mayor a 0.1

            if (cocheEnMovimiento && !audioSource.isPlaying)
            {
                audioSource.Play();
            }
            else if (!cocheEnMovimiento && audioSource.isPlaying)
            {
                audioSource.Stop();
            }
        }

        // Verificar si la vida llega a cero
        if (vida <= 0)
        {
            Explotar();
        }
    }

    void FixedUpdate()
    {
        // Verifica si el coche est� detenido y no procesar m�s entradas
        if (cocheDetenido)
        {
            motorActual = 0f; // Detener el motor
            return; // Si el coche est� detenido, no procesamos los controles de movimiento
        }

        float inputVertical = Input.GetAxis("Vertical");

        if (inputVertical > 0)
        {
            motorActual = Mathf.Lerp(motorActual, maxMotorTorsion, aceleracionProgresiva * Time.deltaTime);
            enReversa = false;
        }
        else if (inputVertical < 0)
        {
            motorActual = Mathf.Lerp(motorActual, -maxMotorTorsion, aceleracionProgresiva * Time.deltaTime);
            enReversa = true;
        }
        else
        {
            motorActual = Mathf.Lerp(motorActual, 0, frenadoAdicional * Time.deltaTime);
        }

        if (motorActual == 0 && inputVertical > 0)
        {
            motorActual = velocidadInicial;
        }

        float direccion = maxAnguloDeGiro * Input.GetAxis("Horizontal");

        foreach (infoEje ejesInfo in infoEjes)
        {
            if (ejesInfo.direccion)
            {
                ejesInfo.ruedaIzquierda.steerAngle = direccion;
                ejesInfo.ruedaDerecha.steerAngle = direccion;
            }

            if (ejesInfo.motor)
            {
                ejesInfo.ruedaIzquierda.motorTorque = motorActual;
                ejesInfo.ruedaDerecha.motorTorque = motorActual;
            }

            posRuedas(ejesInfo.ruedaIzquierda);
            posRuedas(ejesInfo.ruedaDerecha);
        }
    }

    void posRuedas(WheelCollider collider)
    {
        if (collider.transform.childCount == 0) return;

        Transform ruedaVisual = collider.transform.GetChild(0);
        Vector3 posicion;
        Quaternion rotacion;
        collider.GetWorldPose(out posicion, out rotacion);

        ruedaVisual.transform.position = posicion;
        ruedaVisual.transform.rotation = rotacion;
    }

    void ResetPosition()
    {
        transform.position = posicionInicial;
        transform.rotation = rotacionInicial;
        motorActual = 0;
    }

    private void VolverAlUltimoPuntoDeControl()
    {
        if (ultimoPuntoDeControl != null)
        {
            transform.position = ultimoPuntoDeControl.position;
            transform.rotation = ultimoPuntoDeControl.rotation;

            Rigidbody rb = GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.velocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }
            Debug.Log("Carro regres� al �ltimo punto de control.");
        }
        else
        {
            Debug.LogWarning("No hay ning�n punto de control registrado.");
        }
    }

    public void ActualizarPuntoDeControl(Transform nuevoPuntoDeControl)
    {
        ultimoPuntoDeControl = nuevoPuntoDeControl;
        Debug.Log("Punto de control actualizado: " + nuevoPuntoDeControl.name);
    }

    private void OnTriggerEnter(Collider other)
    {
        // Detectar puntos de control
        if (other.CompareTag("PuntoDeControl"))
        {
            ActualizarPuntoDeControl(other.transform);
            Debug.Log("Punto de control alcanzado: " + other.name);
        }

        if (other.CompareTag("ataque")) // Verifica si es un punto de control de ataque
        {
            Debug.Log("�Punto de ataque alcanzado!");
            // Iniciar persecuci�n seg�n el enemigo
            if (other.name == "persecusion1") // Asumiendo que tienes nombres espec�ficos para los puntos de control
            {
                Debug.Log("Inicia la persecuci�n contra el primer enemigo.");
                carroEnemigo1.GetComponent<EnemyPersecution>().IniciarPersecucion(duracionPersecucion);
            }
            else if (other.name == "persecusion2")
            {
                Debug.Log("Inicia la persecuci�n contra el segundo enemigo.");
                carroEnemigo2.GetComponent<EnemyPersecution>().IniciarPersecucion(duracionPersecucion);
            }
            else if (other.name == "persecusion3")
            {
                Debug.Log("Inicia la persecuci�n contra el tercer enemigo.");
                carroEnemigo3.GetComponent<EnemyPersecution>().IniciarPersecucion(duracionPersecucion);
            }
            else if (other.name == "persecusion0")
            {
                Debug.Log("Inicia la persecuci�n contra el cuarto enemigo.");
                carroEnemigo4.GetComponent<EnemyPersecution>().IniciarPersecucion(duracionPersecucion);
            }

            // Si quieres que el punto de control sea destruido al tocarlo
            Destroy(other.gameObject); // Destruye el punto de control de ataque una vez tocado

            // Actualizar el �ltimo punto de control alcanzado (si es necesario)
            ActualizarPuntoDeControl(other.transform);
        }

        // Detectar objeto que detendr� el coche
        if (other.CompareTag("Detener"))
        {
            Debug.Log("Coche detenido por el objeto detenedor");
            cocheDetenido = true; // Cambiar estado a detenido
            motorActual = 0f; // Detener el coche inmediatamente
            rb.velocity = Vector3.zero; // Asegurarse de que el coche se detiene completamente
            PantallaMeta(); 
        }

        if (other.CompareTag("lifePoint"))
        {
            // Verifica si la vida no est� al m�ximo
            HealthPoint2 health = GetComponent<HealthPoint2>();
            if (health != null && health.vida < health.vidaMaxima)
            {
                health.RegenerarVida(10f); // Regenera 10 puntos de vida
                Debug.Log("Vida regenerada al pasar por un punto de vida.");

                // Destruir el objeto del punto de vida despu�s de regenerar vida
                Destroy(other.gameObject);
            }
            else
            {
                Debug.Log("La vida est� al m�ximo, el punto de vida no se destruye.");
            }
        }
    }
    
    public void PantallaMeta()
    {
        Debug.Log("");
        SceneManager.LoadScene("Victory");
    }

    public void Explotar()
    {
        if (explosionPrefab != null)
        {
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);
        }

        gameObject.SetActive(false);
        Debug.Log("�El coche ha explotado!");
    }
}