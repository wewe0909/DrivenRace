using UnityEngine;

public class DelayedAudio : MonoBehaviour
{
    public AudioSource audioSource;

    void Awake()
    {
        // Ensure the audio doesn't play immediately
        audioSource.Stop();
    }

    void Start()
    {
        // Call the PlayAudio method after 2 seconds
        Invoke("PlayAudio", 2f);
    }

    void PlayAudio()
    {
        // Start playing the audio
        audioSource.Play();
    }
}
