using System.Collections;
using System.Collections.Generic;
using Ink.Runtime;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class Dialogue2 : MonoBehaviour
{
    // UI Elements
    public TextMeshProUGUI charText;
    public GameObject PanelDialog;
    public GameObject PanelName;
    public TextMeshProUGUI charName;
    public Button choice1btn;
    public Button choice2btn;
    public TextMeshProUGUI choice1text;
    public TextMeshProUGUI choice2text;

    // -------------------------------------------------------

    // BACKGROUNDS

    public RawImage BgImage;

    // PERSONAJES

    public Image surgeon;

    public Image nurse1;
    public Image nurse2;

    public Image elon1;
    public Image elon2;

    // AUDIOS

    public AudioClip audio_nurse_heyHesWakingUp; 
    public AudioClip audio_nurse_sigh; 
    public AudioClip audio_nurse_well; 
    public AudioClip audio_nurse_laugh; 

    public AudioClip audio_surgeon_nice; 
    public AudioClip audio_surgeon_laugh; 
    public AudioClip audio_surgeon_well; 
    public AudioClip audio_surgeon_nope; 
    public AudioClip audio_surgeon_morphine; 


    public AudioClip audio_elon_hello; 
    public AudioClip audio_elon_laugh; 
    public AudioClip audio_elon_nope; 
    public AudioClip audio_elon_listen; 
    public AudioClip audio_elon_counting; 
    public AudioClip audio_elon_letsbegin; 

    // -------------------------------------------------------
    private Story currentStory;
    private bool isTyping = false;
    private List<Choice> choices = new List<Choice>();

    public Canvas dialogueCanvas;
    public AudioSource dialogueAudio;

    // Hide all UI elements
    public void hideInterface()
    {
        if (PanelDialog != null)
            PanelDialog.SetActive(false);
        if (PanelName != null)
            PanelName.SetActive(false);
        if (charText != null)
            charText.gameObject.SetActive(false);
        if (charName != null)
            charName.gameObject.SetActive(false);

        if (surgeon != null)
            surgeon.gameObject.SetActive(false);
        if (nurse1 != null)
            nurse1.gameObject.SetActive(false);
        if (nurse2 != null)
            nurse2.gameObject.SetActive(false);
        if (elon1 != null)
            elon1.gameObject.SetActive(false);
        if (elon2 != null)
            elon2.gameObject.SetActive(false);

        if (choice1btn != null)
            choice1btn.gameObject.SetActive(false);
        if (choice2btn != null)
            choice2btn.gameObject.SetActive(false);
        if (choice1text != null)
            choice1text.gameObject.SetActive(false);
        if (choice2text != null)
            choice2text.gameObject.SetActive(false);
    }

    public void showInterface()
    {
        if (PanelDialog != null)
            PanelDialog.SetActive(true);
        if (PanelName != null)
            PanelName.SetActive(true);
        if (charText != null)
            charText.gameObject.SetActive(true);
        if (charName != null)
            charName.gameObject.SetActive(true);
    }

    public void showChoice1Btn(){
        if (choice1btn != null)
            choice1btn.gameObject.SetActive(true);
        if (choice1text != null)
            choice1text.gameObject.SetActive(true);
        choice1btn.interactable = true;
    }

    public void showChoice2Btn(){
        if (choice2btn != null)
            choice2btn.gameObject.SetActive(true);
        if (choice2text != null)
            choice2text.gameObject.SetActive(true);
    }

    public void hideChoice1Btn(){
        if (choice1btn != null)
            choice1btn.gameObject.SetActive(false);
        if (choice1text != null)
            choice1text.gameObject.SetActive(false);
    }

    public void hideChoice2Btn(){
        if (choice2btn != null)
            choice2btn.gameObject.SetActive(false);
        if (choice2text != null)
            choice2text.gameObject.SetActive(false);
    }

    void Start()
    {
        hideInterface();
        choice1btn.onClick.AddListener(() => MakeChoice(0));
        choice2btn.onClick.AddListener(() => MakeChoice(1));
        EnterDialogueMode();
    }

    public void EnterDialogueMode()
    {
        showInterface();

        TextAsset inkJSON = Resources.Load<TextAsset>("dialogue2.ink");
        if (inkJSON != null)
        {
            currentStory = new Story(inkJSON.text);
            StartCoroutine(PlayDialogue()); 
        }
        else
        {
            Debug.LogError("Ink JSON file not found!");
        }
    }

        IEnumerator PlayDialogue()
        {
            while (currentStory.canContinue)  // Use canContinue with lowercase 'c'
            {
                string text = currentStory.Continue(); // Get next line of dialogue
                
    
                
                // AUDIOS ------------------------------------------------

                // Nurse: 
                if (currentStory.currentTags.Contains("audio_nurse_heyHesWakingUp"))
                {
                    dialogueAudio.clip = audio_nurse_heyHesWakingUp;
                }
                else if (currentStory.currentTags.Contains("audio_nurse_sigh"))
                {
                    dialogueAudio.clip = audio_nurse_sigh;
                }
                else if (currentStory.currentTags.Contains("audio_nurse_well"))
                {
                    dialogueAudio.clip = audio_nurse_well;
                }
                else if (currentStory.currentTags.Contains("audio_nurse_laugh"))
                {
                    dialogueAudio.clip = audio_nurse_laugh;
                }

                // Surgeon:
                else if (currentStory.currentTags.Contains("audio_surgeon_nice"))
                {
                    dialogueAudio.clip = audio_surgeon_nice;
                }
                else if (currentStory.currentTags.Contains("audio_surgeon_laugh"))
                {
                    dialogueAudio.clip = audio_surgeon_laugh;
                }
                else if (currentStory.currentTags.Contains("audio_surgeon_well"))
                {
                    dialogueAudio.clip = audio_surgeon_well;
                }
                else if (currentStory.currentTags.Contains("audio_surgeon_nope"))
                {
                    dialogueAudio.clip = audio_surgeon_nope;
                }
                else if (currentStory.currentTags.Contains("audio_surgeon_morphine"))
                {
                    dialogueAudio.clip = audio_surgeon_morphine;
                }

                // ElonMusk: 

                else if (currentStory.currentTags.Contains("audio_elon_hello"))
                {
                    dialogueAudio.clip = audio_elon_hello;
                }
                else if (currentStory.currentTags.Contains("audio_elon_laugh"))
                {
                    dialogueAudio.clip = audio_elon_laugh;
                }
                else if (currentStory.currentTags.Contains("audio_elon_nope"))
                {
                    dialogueAudio.clip = audio_elon_nope;
                }
                else if (currentStory.currentTags.Contains("audio_elon_listen"))
                {
                    dialogueAudio.clip = audio_elon_listen;
                }
                else if (currentStory.currentTags.Contains("audio_elon_counting"))
                {
                    dialogueAudio.clip = audio_elon_counting;
                }
                else if (currentStory.currentTags.Contains("audio_elon_letsbegin"))
                {
                    dialogueAudio.clip = audio_elon_letsbegin;
                }

                // Reset: 
                else
                {
                    dialogueAudio.clip = null;
                }

                // PERSONAJES ------------------------------------------------
                // Nurse: 
                if (currentStory.currentTags.Contains("image_nurse1"))
                {
                    nurse1.gameObject.SetActive(true);
                }
                else
                {
                    nurse1.gameObject.SetActive(false);
                }
                if (currentStory.currentTags.Contains("image_nurse2"))
                {
                    nurse2.gameObject.SetActive(true);
                }
                else
                {
                    nurse2.gameObject.SetActive(false);
                }
                // Surgeon:
                if (currentStory.currentTags.Contains("image_surgeon"))
                {
                    surgeon.gameObject.SetActive(true);
                }
                else
                {
                    surgeon.gameObject.SetActive(false);
                }
                // Elon: 
                if (currentStory.currentTags.Contains("image_elon1"))
                {
                    elon1.gameObject.SetActive(true);
                }
                else
                {
                    elon1.gameObject.SetActive(false);
                }
                if (currentStory.currentTags.Contains("image_elon2"))
                {
                    elon2.gameObject.SetActive(true);
                }
                else
                {
                    elon2.gameObject.SetActive(false);
                }

                // BACKGROUNDS ------------------------------------------------
                if (currentStory.currentTags.Contains("blackshock"))
                {
                    StartCoroutine(BlackShock());
                }

                // NEXT SCENE LOAD -------------------------------------------
                if (currentStory.currentTags.Contains("changescene")){
                    StartCoroutine(NextScene());

                }
                // Show character name and dialogue text
                yield return StartCoroutine(TypeSentence(text));

                // Check if there are choices after dialogue
                ProcessChoices();

                // Wait for player to choose an option
                while (choices.Count > 0 && !isTyping)
                {
                    yield return null;
                }
            }
        }


    private IEnumerator NextScene(){
        yield return new WaitForSeconds(5.0f);
        SceneManager.LoadScene("04_loading");
    }

    private IEnumerator BlackShock()
    {
        // Ensure the image starts fully transparent
        Color color = BgImage.color;
        color.a = 0f;
        BgImage.color = color;

        // Enable the RawImage component (in case it's disabled)
        BgImage.gameObject.SetActive(true);

        float fadeDuration = 1.0f; // Duration of fade
        float elapsedTime = 0f;

        while (elapsedTime < fadeDuration)
        {
            elapsedTime += Time.deltaTime;
            color.a = Mathf.Clamp01(elapsedTime / fadeDuration);
            BgImage.color = color;
            yield return null; // Wait for the next frame
        }

        // Ensure it's fully black after fading
        color.a = 1f;
        BgImage.color = color;
    }
    // Typewriter effect for the dialogue text
    IEnumerator TypeSentence(string sentence)
    {
         
        isTyping = true;
        
        charText.text = ""; // Clear previous text
        dialogueAudio.Play();
        foreach (char letter in sentence.ToCharArray())
        {
            charText.text += letter;  // Add one character at a time
            yield return new WaitForSeconds(0.01f);  // Typing speed delay
        }

        isTyping = false;
    }

    // Handle choices in the dialogue
    void ProcessChoices()
    {
        choices.Clear();  // Clear previous choices

        // Hide all choice buttons initially
        hideChoice1Btn();
        hideChoice2Btn();

        // Show choices if available
        if (currentStory.currentChoices.Count > 0)  // Check if there are any choices
        {
            for (int i = 0; i < currentStory.currentChoices.Count; i++)
            {
                Choice choice = currentStory.currentChoices[i];

                // Show and configure choice buttons
                if (i == 0)
                {
                    showChoice1Btn();
                    choice1text.text = choice.text;

                    // Remove previous listeners and add a new one with a debug log
                    choice1btn.onClick.RemoveAllListeners();
                    choice1btn.onClick.AddListener(() => {
                        MakeChoice(0);
                    });
                }
                else if (i == 1)
                {
                    showChoice2Btn();
                    choice2text.text = choice.text;

                    // Remove previous listeners and add a new one with a debug log
                    choice2btn.onClick.RemoveAllListeners();
                    choice2btn.onClick.AddListener(() => {
                        MakeChoice(1);
                    });
                }

                // Add the choice to the list (for processing later)
                choices.Add(choice);
            }
        }
    }


    // Handle the player's choice selection
    void MakeChoice(int choiceIndex)
    {
        // Choose the selected option in the Ink story
        currentStory.ChooseChoiceIndex(choiceIndex);
        hideChoice1Btn();
        hideChoice2Btn();

        // Continue the dialogue after making a choice
        StartCoroutine(PlayDialogue());
    }
}
