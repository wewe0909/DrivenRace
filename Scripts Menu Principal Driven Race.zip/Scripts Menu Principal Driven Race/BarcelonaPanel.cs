using UnityEngine;
using UnityEngine.SceneManagement;

public class BarcelonaPanel : MonoBehaviour
{
    // This method will be triggered when the panel is clicked
    public void OnPanelClick()
    {
        Debug.Log("Loading single race: Barcelona");

        // Adding a 0.5-second delay before loading the scene
        Invoke("LoadBarcelonaScene", 0.5f);
    }

    // Function to actually load the Barcelona scene
    private void LoadBarcelonaScene()
    {
        SceneManager.LoadScene("SingleRaceBarcelona");
    }
}
