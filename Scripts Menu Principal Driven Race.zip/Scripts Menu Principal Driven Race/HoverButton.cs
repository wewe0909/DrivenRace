using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI; // To access the Text and Image components

public class HoverButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    private RectTransform buttonRectTransform; // To get the button's RectTransform
    private Text buttonText; // Reference to the Text component
    private Image buttonImage; // Reference to the Image component (Target Graphic)
    private Vector3 originalScale; // Store the original scale
    public float scaleFactor = 1.05f; // Scale to 105%
    public float scaleSpeed = 5f; // Speed at which the button scales
    public float colorSpeed = 3f; // Speed at which the color changes

    private Color originalColor = Color.white; // Original text color (white)
    private Color targetColor = new Color(0.639f, 0.094f, 0.094f); // Target text color #A41818 (Red)
    private Color originalButtonColor = Color.white; // Original button image color (white)
    private Color targetButtonColor = new Color(0.639f, 0.094f, 0.094f); // Target button image color #A41818

    private AudioSource audioSource; // Reference to the AudioSource component
    public AudioClip hoverSound; // The sound to play when the button is hovered over (assign in the Inspector)

    void Start()
    {
        // Get the RectTransform component of the button
        buttonRectTransform = GetComponent<RectTransform>();
        originalScale = buttonRectTransform.localScale; // Save the original scale of the button

        // Get the Text component on the button
        buttonText = GetComponentInChildren<Text>(); // Assuming the Text component is a child of the button

        // Get the Image component (Target Graphic) on the button
        buttonImage = GetComponent<Image>(); // Assuming the Image component is on the button itself

        // Get the AudioSource component on the button
        audioSource = GetComponent<AudioSource>();
        
        if (audioSource == null) // If no AudioSource is attached, add one
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    void Update()
    {
        // Smoothly interpolate the scale
        if (buttonRectTransform.localScale != originalScale)
        {
            buttonRectTransform.localScale = Vector3.Lerp(buttonRectTransform.localScale, originalScale * scaleFactor, Time.deltaTime * scaleSpeed);
        }
    }

    // When the pointer enters the button
    public void OnPointerEnter(PointerEventData eventData)
    {
        // Trigger smooth scaling to 105%
        StopAllCoroutines(); // Stop any running coroutine (if there was any)
        StartCoroutine(ScaleButton(originalScale * scaleFactor));

        // Start changing the text color smoothly to #A41818
        StartCoroutine(ChangeTextColor(originalColor, targetColor));

        // Start changing the button image color smoothly to #A41818
        StartCoroutine(ChangeButtonColor(originalButtonColor, targetButtonColor));

        // Play the hover sound (only if it’s not already playing)
        if (hoverSound != null && !audioSource.isPlaying) // Only play if the sound is not already playing
        {
            audioSource.PlayOneShot(hoverSound);
        }

        // Explicitly set the cursor to the hand pointer (optional)
        Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
    }

    // When the pointer exits the button
    public void OnPointerExit(PointerEventData eventData)
    {
        // Trigger smooth scaling back to original size
        StopAllCoroutines(); // Stop any running coroutine (if there was any)
        StartCoroutine(ScaleButton(originalScale));

        // Start changing the text color smoothly back to white
        StartCoroutine(ChangeTextColor(targetColor, originalColor));

        // Start changing the button image color smoothly back to white
        StartCoroutine(ChangeButtonColor(targetButtonColor, originalButtonColor));

        // Reset the cursor back to default (optional)
        Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
    }

    // Coroutine to smoothly scale the button
    private IEnumerator ScaleButton(Vector3 targetScale)
    {
        Vector3 initialScale = buttonRectTransform.localScale;
        float timeElapsed = 0;

        while (timeElapsed < 1)
        {
            buttonRectTransform.localScale = Vector3.Lerp(initialScale, targetScale, timeElapsed);
            timeElapsed += Time.deltaTime * scaleSpeed;
            yield return null;
        }

        buttonRectTransform.localScale = targetScale;
    }

    // Coroutine to smoothly change the text color
    private IEnumerator ChangeTextColor(Color fromColor, Color toColor)
    {
        float timeElapsed = 0;

        // Only proceed if the button has a Text component
        if (buttonText != null)
        {
            while (timeElapsed < 1)
            {
                buttonText.color = Color.Lerp(fromColor, toColor, timeElapsed);
                timeElapsed += Time.deltaTime * colorSpeed;
                yield return null;
            }
            
            // Ensure it ends at the exact target color
            buttonText.color = toColor;
        }
    }


    // Coroutine to smoothly change the button image color
    private IEnumerator ChangeButtonColor(Color fromColor, Color toColor)
    {
        float timeElapsed = 0;

        while (timeElapsed < 1)
        {
            buttonImage.color = Color.Lerp(fromColor, toColor, timeElapsed);
            timeElapsed += Time.deltaTime * colorSpeed;
            yield return null;
        }

        buttonImage.color = toColor;
    }
}
