using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class HoverButton02 : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    private Text buttonText; // Reference to the Text component
    private Image buttonImage; // Reference to the Image component (Target Graphic)

    public float colorSpeed = 3f; // Speed at which the color changes

    // Text color settings: semi-transparent when not hovered, fully opaque when hovered
    private Color originalTextColor = new Color(1f, 1f, 1f, 0.2f); // Semi-transparent white (50 alpha)
    private Color targetTextColor = Color.white; // Fully opaque white (255 alpha)

    private AudioSource audioSource; // Reference to the AudioSource component
    public AudioClip hoverSound; // The sound to play when the button is hovered over (assign in the Inspector)

    void Start()
    {
        // Get the Text component on the button
        buttonText = GetComponentInChildren<Text>();

        // Get the Image component (Target Graphic) on the button
        buttonImage = GetComponent<Image>();

        // Get or add the AudioSource component
        audioSource = GetComponent<AudioSource>();
        
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        StopAllCoroutines();

        // Start changing text to fully opaque
        StartCoroutine(ChangeTextColor(originalTextColor, targetTextColor));

        // Play the hover sound if not already playing
        if (hoverSound != null && !audioSource.isPlaying)
        {
            audioSource.PlayOneShot(hoverSound);
        }

        Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        StopAllCoroutines();

        // Start changing text color back to semi-transparent
        StartCoroutine(ChangeTextColor(targetTextColor, originalTextColor));

        Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
    }

    private IEnumerator ChangeTextColor(Color fromColor, Color toColor)
    {
        float timeElapsed = 0;

        // Only proceed if the button has a Text component
        if (buttonText != null)
        {
            while (timeElapsed < 1)
            {
                buttonText.color = Color.Lerp(fromColor, toColor, timeElapsed);
                timeElapsed += Time.deltaTime * colorSpeed;
                yield return null;
            }

            // Ensure it ends at the exact target color
            buttonText.color = toColor;
        }
    }
}
