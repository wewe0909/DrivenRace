using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class HoveringPanel : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Header("UI Elements")]
    public Image targetImage;
    public Text targetText;

    [Header("Animation Settings")]
    public float scaleFactor = 1.1f;
    public float opacity = 0.8f;
    public float animationDuration = 0.3f;

    [Header("Audio Settings")]
    public AudioClip hoverSound;
    public AudioSource audioSource;

    private Vector3 originalScaleImage;
    private Vector3 originalScaleText;
    private Color originalColorImage;
    private bool isHovered = false;

    private void Start()
    {
        if (targetImage != null)
        {
            originalScaleImage = targetImage.transform.localScale;
            originalColorImage = targetImage.color;
        }

        if (targetText != null)
        {
            originalScaleText = targetText.transform.localScale;
        }

        if (audioSource == null && hoverSound != null)
        {
            // Automatically add an AudioSource if not set
            audioSource = gameObject.AddComponent<AudioSource>();
            audioSource.playOnAwake = false;
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        isHovered = true;
        if (audioSource != null && hoverSound != null)
        {
            audioSource.PlayOneShot(hoverSound);
        }
        StopAllCoroutines();
        StartCoroutine(AnimateHover(true));
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        isHovered = false;
        StopAllCoroutines();
        StartCoroutine(AnimateHover(false));
    }

    private System.Collections.IEnumerator AnimateHover(bool hovering)
    {
        float timeElapsed = 0;
        Vector3 targetScaleImage = originalScaleImage;
        Vector3 targetScaleText = originalScaleText;
        Color targetColorImage = originalColorImage;

        if (hovering)
        {
            if (targetImage != null)
            {
                targetScaleImage *= scaleFactor;
                targetColorImage.a = opacity;
            }

            if (targetText != null)
            {
                targetScaleText *= scaleFactor;
            }
        }

        while (timeElapsed < animationDuration)
        {
            float t = timeElapsed / animationDuration;
            t = Mathf.SmoothStep(0, 1, t);

            if (targetImage != null)
            {
                targetImage.transform.localScale = Vector3.Lerp(
                    targetImage.transform.localScale,
                    hovering ? targetScaleImage : originalScaleImage,
                    t
                );
                targetImage.color = Color.Lerp(
                    targetImage.color,
                    hovering ? targetColorImage : originalColorImage,
                    t
                );
            }

            if (targetText != null)
            {
                targetText.transform.localScale = Vector3.Lerp(
                    targetText.transform.localScale,
                    hovering ? targetScaleText : originalScaleText,
                    t
                );
            }

            timeElapsed += Time.deltaTime;
            yield return null;
        }

        // Finalize animation to ensure precision
        if (targetImage != null)
        {
            targetImage.transform.localScale = hovering ? targetScaleImage : originalScaleImage;
            targetImage.color = hovering ? targetColorImage : originalColorImage;
        }

        if (targetText != null)
        {
            targetText.transform.localScale = hovering ? targetScaleText : originalScaleText;
        }
    }
}
