using UnityEngine;
using UnityEngine.SceneManagement;

public class LondonPanel : MonoBehaviour
{
    // This method will be triggered when the panel is clicked
    public void OnPanelClick()
    {
        Debug.Log("Loading single race: London");

        // Adding a 0.5-second delay before loading the scene
        Invoke("LoadLondonScene", 0.5f);
    }

    // Function to actually load the Barcelona scene
    private void LoadLondonScene()
    {
        SceneManager.LoadScene("SingleLondon");
    }
}
