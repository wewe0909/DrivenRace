using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnButtonClick : MonoBehaviour
{
    public void ButtonClick()
    {
        Debug.Log("Button Clicked!");
    }
}
