using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PersistentEventListener : MonoBehaviour
{
    public static PersistentEventListener instance;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);  // Keep this GameObject across scenes
        }
        else
        {
            Destroy(gameObject);  // Destroy duplicate GameObjects
        }
    }
}
