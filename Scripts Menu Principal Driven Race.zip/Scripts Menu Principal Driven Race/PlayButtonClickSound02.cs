using UnityEngine;
using UnityEngine.UI;

public class PlayButtonClickSound02 : MonoBehaviour
{
    // Public AudioClip to assign in the Inspector
    public AudioClip buttonClickSound;

    // Private AudioSource reference
    private AudioSource audioSource;

    void Start()
    {
        // Try to get the AudioSource component attached to this GameObject
        audioSource = GetComponent<AudioSource>();

        // If no AudioSource is attached, add one
        if (audioSource == null)
        {
            Debug.LogWarning("No AudioSource found! Adding one.");
            audioSource = gameObject.AddComponent<AudioSource>();
        }

        // Optionally, configure the AudioSource (volume, loop, etc.)
        audioSource.playOnAwake = false;  // Ensure the AudioSource doesn't play automatically at start
    }

    // This function will be called when the button is clicked
    public void PlaySoundOnClick()
    {
        // Check if the sound clip is assigned
        if (buttonClickSound != null)
        {
            // Play the button click sound
            audioSource.PlayOneShot(buttonClickSound);
        }
        else
        {
            // Log an error if the sound clip is missing
            Debug.LogError("Button click sound is not assigned!");
        }
    }
}
