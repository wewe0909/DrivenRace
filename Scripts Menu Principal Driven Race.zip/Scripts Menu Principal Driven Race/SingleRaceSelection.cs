using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SingleRaceSelection : MonoBehaviour
{
    void Start()
    {
        
    }

    public void SelectBarcelona()
    {
        Debug.Log("Lodeando single races");

        // Adding a 0.5-second delay before loading the scene
        Invoke("Barcelona", 0.5f);
    }

    // Function to actually load the Settings scene
    private void Barcelona()
    {
        Debug.Log("");
        DestroyAllDontDestroyOnLoad();
        SceneManager.LoadScene("SingleBarcelona");
    }

    public void SelectLondon()
    {
        Debug.Log("Lodeando single races");

        // Adding a 0.5-second delay before loading the scene
        Invoke("London", 0.5f);
    }

    // Function to actually load the Settings scene
    private void London()
    {
        Debug.Log("");
        DestroyAllDontDestroyOnLoad();
        SceneManager.LoadScene("SingleLondon");
    }

    private void DestroyAllDontDestroyOnLoad()
    {
        // Find all GameObjects in DontDestroyOnLoad
        GameObject[] allObjects = FindObjectsOfType<GameObject>();

        foreach (GameObject obj in allObjects)
        {
            if (obj.scene.name == null || obj.scene.name == "") // Belongs to DontDestroyOnLoad
            {
                Destroy(obj); // Destroy it
                Debug.Log($"Destroyed object: {obj.name}");
            }
        }

        // Explicitly handle the Singleton case
        if (PersistentAudioListener.instance != null)
        {
            Destroy(PersistentAudioListener.instance.gameObject);
            PersistentAudioListener.instance = null; // Clear reference
            Debug.Log("Destroyed PersistentAudioListener.");
        }

         if (PersistentCanvas.instance != null)
        {
            Destroy(PersistentCanvas.instance.gameObject);
            PersistentCanvas.instance = null; // Clear reference
            Debug.Log("Destroyed PersistentCanvas.");
        }
    }

}
