using UnityEngine;
using UnityEngine.SceneManagement;

public class StartMenuManager : MonoBehaviour
{
    // Debug to confirm no AudioSource is needed
    void Start()
    {
        Debug.Log("Start method called. No AudioSource required anymore.");
    }

    public void LoadSingleScene()
    {
        Debug.Log("Lodeando single races");

        // Adding a 0.5-second delay before loading the scene
        Invoke("LoadSingle", 0.5f);
    }

    // Function to actually load the Settings scene
    private void LoadSingle()
    {
        Debug.Log("");
        SceneManager.LoadScene("StartMenu_Single");
    }

    public void LoadNewStoryScene()
    {
        Debug.Log("Lodeando nueva story");

        // Adding a 0.5-second delay before loading the scene
        Invoke("LoadNewStory", 0.5f);
    }

    // Function to actually load the Settings scene
    private void LoadNewStory()
    {
        Debug.Log("");
        DestroyAllDontDestroyOnLoad();
        SceneManager.LoadScene("00_loading");
    }

    public void LoadSettingsScene()
    {
        Debug.Log("LoadSettingsScene function called.");

        // Adding a 0.5-second delay before loading the scene
        Invoke("LoadSettings", 0.5f);
    }

    // Function to actually load the Settings scene
    private void LoadSettings()
    {
        Debug.Log("Loading scene: StartMenu_Settings");
        SceneManager.LoadScene("StartMenu_Settings");
    }

    // Function to load the Story Archive scene with a delay
    public void LoadStoryArchiveScene()
    {
        Debug.Log("LoadStoryArchiveScene function called.");

        // Adding a 0.5-second delay before loading the scene
        Invoke("LoadStoryArchive", 0.5f);
    }

    // Function to actually load the Story Archive scene
    private void LoadStoryArchive()
    {
        Debug.Log("Loading scene: StartMenu_Archive");
        SceneManager.LoadScene("StartMenu_Archive");
    }

    // Function to load the Start Menu scene with a delay
    public void LoadStartMenuScene()
    {
        Debug.Log("LoadStartMenuScene function called.");

        // Adding a 0.5-second delay before loading the scene
        Invoke("LoadStartMenu", 0.5f);
    }

    // Function to actually load the Start Menu scene
    private void LoadStartMenu()
    {
        Debug.Log("Loading scene: StartMenu");
        SceneManager.LoadScene("StartMenu");
    }


    private void DestroyAllDontDestroyOnLoad()
    {
        // Find all GameObjects in DontDestroyOnLoad
        GameObject[] allObjects = FindObjectsOfType<GameObject>();

        foreach (GameObject obj in allObjects)
        {
            if (obj.scene.name == null || obj.scene.name == "") // Belongs to DontDestroyOnLoad
            {
                Destroy(obj); // Destroy it
                Debug.Log($"Destroyed object: {obj.name}");
            }
        }

        // Explicitly handle the Singleton case
        if (PersistentAudioListener.instance != null)
        {
            Destroy(PersistentAudioListener.instance.gameObject);
            PersistentAudioListener.instance = null; // Clear reference
            Debug.Log("Destroyed PersistentAudioListener.");
        }
        if (PersistentCanvas.instance != null)
        {
            Destroy(PersistentCanvas.instance.gameObject);
            PersistentCanvas.instance = null; // Clear reference
            Debug.Log("Destroyed PersistentCanvas.");
        }
    }



}
